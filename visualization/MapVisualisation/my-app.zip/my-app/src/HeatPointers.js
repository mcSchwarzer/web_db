/*global google*/
import React from 'react';
import HeatmapLayer from "react-google-maps/lib/components/visualization/HeatmapLayer";

const HeatPointers = (props) => {
    var final = this.props.data.map(marker => {
        if (marker.latitude !== 0 && marker.longitude !== 0) {
            return (new google.maps.LatLng(marker.latitude, marker.longitude));
        }
    })
    return (
        <HeatmapLayer
            data={final}
        />
    )
}

export default HeatPointers;