import React from 'react';
import { compose, withProps } from "recompose";
import {
    withScriptjs,
    withGoogleMap,
    GoogleMap,
    Marker
} from "react-google-maps";

const Markers = (props) => {
    const marks = props.data.map(marker => {
        if (marker.latitude !== 0 && marker.longitude !== 0) {
            return <Marker position={{ lat: marker.latitude, lng: marker.longitude }} />;
        }
    });

    return (
        <div>
            {marks}
        </div>
    );
}

export default Markers;