import React, { Component } from 'react';
import MyMapComponent from './MapComponent';
import classes from './App.css'

class App extends Component {
  render() {
    return (
      <div className={classes.centering}>
        <h1 className={classes.centering, classes.header}>UFO-SIGHTINGS-MAP</h1>
        <MyMapComponent isMarkerShown />
      </div>
    );
  }
}

export default App;
