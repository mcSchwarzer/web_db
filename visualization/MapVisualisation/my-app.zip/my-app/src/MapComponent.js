// import React from 'react';
// import ReactDOM from 'react-dom';
// import { compose, withProps } from "recompose";
// import {
//     withScriptjs,
//     withGoogleMap,
//     GoogleMap,
//     Marker
// } from "react-google-maps";
// import data from './data.json';
// import Markers from './Markers';
// const { MarkerClusterer } = require("react-google-maps/lib/components/addons/MarkerClusterer");

// const MyMapComponent = compose(
//     withProps({
//         googleMapURL:
//             "https://maps.googleapis.com/maps/api/js?key=AIzaSyBVrlm1DOKsoaiMuWXxUykaIHBNfA8Jl3I&v=3.exp&libraries=geometry,drawing,places",
//         loadingElement: <div style={{ height: `100%` }} />,
//         containerElement: <div style={{ height: `570px` }} />,
//         mapElement: <div style={{ height: `100%` }} />
//     }),
//     withScriptjs,
//     withGoogleMap
// )(props => (
//     <GoogleMap defaultZoom={3} defaultCenter={{ lat: 37.090240, lng: -95.712891 }}>
//         {props.isMarkerShown && (
//             <Markers data={data} />
//         )}
//     </GoogleMap>
// ));

/*global google*/
import React from 'react';
import ReactDOM from 'react-dom';
import data from './fulldata.json';
import Markers from './Markers';
import HeatPointers from './HeatPointers';
import {
    withScriptjs,
    withGoogleMap,
    GoogleMap,
    Marker
} from "react-google-maps";
//import HeatmapLayer from "react-google-maps/lib/visualization/HeatmapLayer";
import HeatmapLayer from "react-google-maps/lib/components/visualization/HeatmapLayer";

const fetch = require("isomorphic-fetch");
const { compose, withProps, withHandlers } = require("recompose");
const { MarkerClusterer } = require("react-google-maps/lib/components/addons/MarkerClusterer");
const default_position = { lat: 37.090240, lng: -95.712891 };

// const MyMapComponent = compose(
//     withProps({
//         googleMapURL: "https://maps.googleapis.com/maps/api/js?key=AIzaSyBVrlm1DOKsoaiMuWXxUykaIHBNfA8Jl3I&v=3.exp&&libraries=visualization,geometry,drawing,places",
//         loadingElement: <div style={{ height: `100%` }} />,
//         containerElement: <div style={{ height: `400px` }} />,
//         mapElement: <div style={{ height: `100%` }} />,
//     }),
//     // withHandlers({
//     //     onMarkerClustererClick: () => (markerClusterer) => {
//     //         const clickedMarkers = markerClusterer.getMarkers()
//     //         console.log(`Current clicked markers length: ${clickedMarkers.length}`)
//     //         console.log(clickedMarkers)
//     //     },
//     // }),
//     withScriptjs,
//     withGoogleMap
// )(props => {
//     /* <GoogleMap
//         defaultZoom={3}
//         defaultCenter={{ lat: 25.0391667, lng: 121.525 }}
//     >
//         <MarkerClusterer
//             onClick={props.onMarkerClustererClick}
//             averageCenter
//             enableRetinaIcons
//             gridSize={60}
//         >
//             {props.isMarkerShown && (
//                 <Markers data={data} />
//             )}
//         </MarkerClusterer>
//     </GoogleMap> }*/
//     <GoogleMap
//         defaultCenter={default_position}
//         defaultZoom={6}
//         >
//         {/* yesIWantToUseGoogleMapApiInternals > */}
//      {/* onGoogleApiLoaded={({ map, maps }) => {
//
//     }} 
//     > **/}
//     </ GoogleMap>
//     }
//     );
/*global google*/

const MyMapComponent = compose(
    withProps({
        googleMapURL: "https://maps.googleapis.com/maps/api/js?key=AIzaSyBVrlm1DOKsoaiMuWXxUykaIHBNfA8Jl3I&v=3.exp&&libraries=visualization,geometry,drawing,places",
        loadingElement: <div style={{ height: `100%` }} />,
        containerElement: <div style={{ height: `560px` }} />,
        mapElement: <div style={{ height: `100%` }} />,
    }),
    withScriptjs,
    withGoogleMap
)(props => {
    return (<GoogleMap
        bootstrapURLKeys={{
            libraries: 'visualization',
        }}
        defaultCenter={default_position}
        defaultZoom={4}
    >
        {/* <HeatPointers data={data} /> */}
        <MarkerClusterer
             onClick={props.onMarkerClustererClick}
             averageCenter
             enableRetinaIcons
             gridSize={60}
         >
             {props.isMarkerShown && (
                 <Markers data={data} />
             )}
         </MarkerClusterer>
    </ GoogleMap>)
}
    );

export default MyMapComponent;